PIXEL EMPIRE — Telegram Mini App starter
1. Распакуй архив.
2. Открой index.html в браузере для проверки.
3. Создай публичный репозиторий GitHub и загрузи index.html, style.css, game.js.
4. GitHub: Settings → Pages → Deploy from a branch → main → /(root) → Save.
5. После публикации вставь URL GitHub Pages в настройки Mini App через BotFather.

Игра одиночная. Прогресс сохраняется в localStorage браузера/Telegram WebView.
Для первой версии сервер не нужен. Не публикуй токен бота в этих файлах.
