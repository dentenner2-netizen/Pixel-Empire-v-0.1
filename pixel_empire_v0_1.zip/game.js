const SAVE_KEY = "pixelEmpireSave_v1";
const freshState = () => ({coins:0,total:0,clickPower:1,clickLevel:0,drillLevel:0,lastSeen:Date.now()});
let state = load();
let toastTimer;
const $ = id => document.getElementById(id);
function load(){
  try { const saved = JSON.parse(localStorage.getItem(SAVE_KEY)); return saved ? {...freshState(),...saved} : freshState(); }
  catch { return freshState(); }
}
function save(){ state.lastSeen=Date.now(); localStorage.setItem(SAVE_KEY,JSON.stringify(state)); }
function drillRate(){ return state.drillLevel; }
function clickCost(){ return Math.floor(25*Math.pow(1.65,state.clickLevel)); }
function drillCost(){ return Math.floor(100*Math.pow(1.7,state.drillLevel)); }
function level(){ return Math.floor(state.total/100)+1; }
function addCoins(amount){
  state.coins += amount; state.total += amount; render(); save();
}
function notify(message){
  const el=$("toast"); el.textContent=message; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),1700);
}
function render(){
  $("coins").textContent=Math.floor(state.coins).toLocaleString("ru-RU");
  $("total").textContent=Math.floor(state.total).toLocaleString("ru-RU")+" ◆";
  $("perClick").textContent=state.clickPower+" ◆";
  $("perSec").textContent=drillRate()+" ◆";
  $("gain").textContent="+"+state.clickPower+" за нажатие";
  $("level").textContent=level();
  $("clickOwned").textContent=state.clickLevel;
  $("drillOwned").textContent=state.drillLevel;
  $("clickCost").textContent=clickCost().toLocaleString("ru-RU");
  $("drillCost").textContent=drillCost().toLocaleString("ru-RU");
  $("buyClick").disabled=state.coins<clickCost();
  $("buyDrill").disabled=state.coins<drillCost();
  const current=state.total%100;
  $("progressText").textContent=Math.floor(current)+" / 100";
  $("progressBar").style.width=current+"%";
}
$("mineButton").addEventListener("click",()=>addCoins(state.clickPower));
$("buyClick").addEventListener("click",()=>{
  const cost=clickCost(); if(state.coins<cost)return;
  state.coins-=cost; state.clickLevel++; state.clickPower++; render(); save(); notify("Кирка улучшена!");
});
$("buyDrill").addEventListener("click",()=>{
  const cost=drillCost(); if(state.coins<cost)return;
  state.coins-=cost; state.drillLevel++; render(); save(); notify("Автобур установлен!");
});
$("resetButton").addEventListener("click",()=>{
  if(confirm("Точно сбросить весь прогресс?")){state=freshState();save();render();notify("Прогресс сброшен");}
});
setInterval(()=>{ if(drillRate()>0)addCoins(drillRate()); },1000);
setInterval(save,5000);
render();

// Telegram Mini App integration (the game also works in a normal browser).
if(window.Telegram?.WebApp){
  const tg=window.Telegram.WebApp;
  tg.ready(); tg.expand();
  try{tg.setHeaderColor("#111020");tg.setBackgroundColor("#111020");}catch(e){}
}
